// alu.v - ALU module

module alu #(parameter WIDTH = 32) (
    input         [WIDTH-1:0] a, b,      // operands
    input         [3:0] ALUControl,      // <-- Widened from [2:0] to [3:0]
    output reg    [WIDTH-1:0] alu_out,   // ALU output
    output        zero                 // zero flag
);

// Shift amount is only the lower 5 bits of b (rs2 or imm) 
wire [4:0] shamt = b[4:0];

always @(a, b, ALUControl, shamt) begin
    case (ALUControl)
        4'b0000:  alu_out <= a + b;                  // ADD
        4'b0001:  alu_out <= a - b;                  // SUB (replaces a + ~b + 1)
        4'b0010:  alu_out <= a & b;                  // AND
        4'b0011:  alu_out <= a | b;                  // OR
        4'b0100:  alu_out <= a ^ b;                  // XOR (Fix for #6, #16)
        4'b0101:  alu_out <= a << shamt;             // SLL (Fix for #3, #13) 
        4'b0110:  alu_out <= a >> shamt;             // SRL (Fix for #7, #17) 
        4'b0111:  alu_out <= $signed(a) >>> shamt;   // SRA (Fix for #8, #18) 
        4'b1000:  alu_out <= $signed(a) < $signed(b) ? 32'd1 : 32'd0; // SLT (Fix for #4, #14)
        4'b1001:  alu_out <= a < b ? 32'd1 : 32'd0;  // SLTU (Fix for #5, #15)
        default:  alu_out = 32'b0;
    endcase
end

assign zero = (alu_out == 32'b0) ? 1'b1 : 1'b0;

endmodule