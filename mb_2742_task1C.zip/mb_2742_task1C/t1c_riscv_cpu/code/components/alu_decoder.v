// alu_decoder.v - logic for ALU decoder

module alu_decoder (
    input               opb5,       // Corresponds to Instr[5]
    input [2:0]         funct3,
    input               funct7b5,   // Corresponds to Instr[30]
    input [1:0]         ALUOp,
    output reg [3:0]    ALUControl
);

always @(*) begin
    case (ALUOp)
        2'b00: ALUControl = 4'b0000;  // addition (for lw, sw, addi)
        2'b01: ALUControl = 4'b0001;  // subtraction (for branches)
        default: // 2'b10 (R-type or I-type ALU)
            case (funct3)
                3'b000: begin // add, addi, sub
                    if (funct7b5 & opb5) ALUControl = 4'b0001; // sub 
                    else ALUControl = 4'b0000; // add, addi 
                end
                3'b001: ALUControl = 4'b0101; // sll, slli 
                3'b010: ALUControl = 4'b1000; // slt, slti 
                3'b011: ALUControl = 4'b1001; // sltu, sltiu 
                3'b100: ALUControl = 4'b0100; // xor, xori 
                3'b101: begin // srl, srli, sra, srai
                    //
                    // --- THIS IS THE FIX ---
                    // Only check funct7b5 to distinguish logical/arithmetic
                    //
                    if (funct7b5) ALUControl = 4'b0111; // sra, srai 
                    else ALUControl = 4'b0110; // srl, srli 
                end
                3'b110: ALUControl = 4'b0011; // or, ori 
                3'b111: ALUControl = 4'b0010; // and, andi 
                default: ALUControl = 4'bxxxx; // ???
            endcase
    endcase
end

endmodule