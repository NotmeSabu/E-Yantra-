// MazeSolver Bot: Task 2B - UART Transmitter
/*
Instructions
-------------------
Students are not allowed to make any changes in the Module declaration.
This file is used to generate UART Tx data packet to transmit the messages based on the input data.
Recommended Quartus Version : 20.1
The submitted project file must be 20.1 compatible as the evaluation will be done on Quartus Prime Lite 20.1.
Warning: The error due to compatibility will not be entertained.
-------------------
*/

/*
Module UART Transmitter

Input:  clk_3125 - 3125 KHz clock
        parity_type - even(0)/odd(1) parity type
        tx_start - signal to start the communication.
data    - 8-bit data line to transmit

Output: tx      - UART Transmission Line
        tx_done - message transmitted flag


        Baudrate : 115200 bps
*/

// module declaration
module uart_tx(
    input clk_3125,
    input parity_type,tx_start,
    input [7:0] data,
    output reg tx, tx_done
);
initial begin
    tx = 1'b1;
    tx_done = 1'b0;
end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE//////////////////
 
    // --- Parameters ---
    localparam CYCLES_PER_BIT = 27;

    // FSM State definitions
    localparam S_IDLE   = 3'd0;
    localparam S_START  = 3'd1;
    localparam S_DATA   = 3'd2;
    localparam S_PARITY = 3'd3;
    localparam S_STOP   = 3'd4;

    // --- Internal Registers ---
    reg [2:0] state;
    reg [4:0] clk_counter;
    reg [2:0] bit_index;     // Counter for data bits (now 7 down to 0)
    
    reg [7:0] tx_data;       // Latched data to be transmitted
    reg       tx_parity;     // Latched parity bit

    // --- Logic ---
    
    // Initialize FSM state
    initial begin
        state = S_IDLE;
        clk_counter = 5'd0;
        bit_index = 3'd0;
        tx_data = 8'd0;
        tx_parity = 1'b0;
    end
    
    // Main FSM and TX logic
    always @(posedge clk_3125)
    begin
        // tx_done is a pulse, so set it to 0 by default
        tx_done <= 1'b0;

        case (state)
            
            // --- IDLE STATE ---
            S_IDLE: begin
                tx <= 1'b1; // TX line is high when idle
                clk_counter <= 5'd0;
                bit_index <= 3'd0;
                
                if (tx_start) begin
                    // Latch the data and calculated parity bit
                    tx_data <= data;
                    tx_parity <= (^data) ^ parity_type;
                    
                    // Start transmission
                    tx <= 1'b0;         // Start bit is low
                    state <= S_START;
                end
            end
            
            // --- START BIT STATE ---
            // Hold start bit for 27 cycles
            S_START: begin
                if (clk_counter < CYCLES_PER_BIT - 1) begin
                    clk_counter <= clk_counter + 1;
                end
                else begin
                    // 27 cycles are done, move to data
                    clk_counter <= 5'd0;
                    tx <= tx_data[7]; // *** CHANGED: Send MSB (bit 7) first ***
                    bit_index <= 3'd7;    // *** CHANGED: Set index to 7 ***
                    state <= S_DATA;
                end
            end
            
            // --- DATA BITS STATE ---
            // Send 8 data bits, MSB to LSB
            S_DATA: begin
                if (clk_counter < CYCLES_PER_BIT - 1) begin
                    clk_counter <= clk_counter + 1;
                end
                else begin
                    // 27 cycles are done, send next bit
                    clk_counter <= 5'd0;
                    
                    if (bit_index > 0) begin // *** CHANGED: Count down ***
                        // Still have data bits to send
                        bit_index <= bit_index - 1;
                        tx <= tx_data[bit_index - 1]; // *** CHANGED: Send next bit (6, 5, 4...) ***
                    end
                    else begin
                        // All 8 data bits sent, move to parity
                        tx <= tx_parity; // Send the parity bit
                        state <= S_PARITY;
                    end
                end
            end
            
            // --- PARITY BIT STATE ---
            // Hold parity bit for 27 cycles
            S_PARITY: begin
                if (clk_counter < CYCLES_PER_BIT - 1) begin
                    clk_counter <= clk_counter + 1;
                end
                else begin
                    // 27 cycles are done, move to stop bit
                    clk_counter <= 5'd0;
                    tx <= 1'b1; // Stop bit is high
                    state <= S_STOP;
                end
            end
            
            // --- STOP BIT STATE ---
            // Hold stop bit for 27 cycles
            S_STOP: begin
					  
                if (clk_counter < CYCLES_PER_BIT - 1) begin
                    clk_counter <= clk_counter + 1;
						  if (clk_counter == 5'd25) begin
							tx_done <= 1'b1;
							end	// Signal completion for one cycle
                end
                else begin
                    // 27 cycles are done, transmission finished
                    clk_counter <= 5'd0;
                    tx_done <= 1'b0; // Stop Signal completion for one cycle
                    state <= S_IDLE;
                end
            end

            // Default case to prevent latches
            default: begin
                state <= S_IDLE;
                clk_counter <= 5'd0;
            end
            
        endcase
    end

//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE//////////////////

endmodule