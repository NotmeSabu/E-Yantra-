module uart_rx(
    input clk_3125,
    input rx,
    output reg [7:0] rx_msg,
    output reg rx_parity,
    output reg rx_complete
    );

initial begin
    rx_msg = 8'b0;
    rx_parity = 1'b0;
    rx_complete = 1'b0;
end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE//////////////////

    // --- Parameters ---
    localparam CYCLES_PER_BIT = 27;

    // FSM State definitions
    localparam S_IDLE     = 3'd0;
    localparam S_START    = 3'd1;
    localparam S_DATA     = 3'd2;
    localparam S_PARITY   = 3'd3;
    localparam S_STOP     = 3'd4;
    localparam S_COMPLETE = 3'd5;

    // --- Internal Registers ---
    reg [2:0] state;
    reg [5:0] clk_counter;      // widened to handle counts safely
    reg [2:0] bit_index; 
    reg [7:0] rx_data;
    reg       rx_parity_bit;
	 reg 		  rx_complete_2;
	 reg 		  flag;


    // Synchronize RX input (metastability protection)
    reg rx_sync1, rx_sync2;
    always @(posedge clk_3125) begin
        rx_sync1 <= rx;
        rx_sync2 <= rx_sync1;
    end
    wire rx_s = rx_sync2;

    // Initialize FSM states
    initial begin
        state = S_IDLE;
        clk_counter = 6'd0;
        bit_index = 3'd0;
        rx_data = 8'd0;
		  rx_complete_2 = 1'b0;
        rx_parity_bit = 1'b0;
		  flag = 1'd0;
    end


    // MAIN FSM and RX logic
    always @(posedge clk_3125)
    begin
        // default: rx_complete = 0 unless in COMPLETE state
        if (state != S_COMPLETE)
            rx_complete <= 1'b0;

        case (state)
            // --- IDLE STATE ---
            S_IDLE: begin
                clk_counter <= 0;
					 rx_complete <= 1'b0;
                bit_index <= 0;
                if (rx_s == 1'b0) begin // start bit detected
                    clk_counter <= 0;
                    state <= S_START;
                end
            end

            // --- START BIT ---
            S_START: begin
                if (clk_counter < (CYCLES_PER_BIT/2)) begin
                    clk_counter <= clk_counter + 1;
                end else begin
                    // sample mid of start bit
                    if (rx_s == 1'b0) begin
                        clk_counter <= 0;
                        bit_index <= 7;
                        state <= S_DATA;
                    end else begin
                        // false start
                        state <= S_IDLE;
                    end
                end
            end

            // --- DATA BITS ---
            S_DATA: begin
                if (clk_counter < CYCLES_PER_BIT - 1) begin
                    clk_counter <= clk_counter + 1;
                end else begin
                    clk_counter <= 0;
                    rx_data[bit_index] <= rx_s;
                    if (bit_index > 0)
                        bit_index <= bit_index - 1;
                    else
                        state <= S_PARITY;
                end
            end

            // --- PARITY BIT ---
            S_PARITY: begin
                if (clk_counter < CYCLES_PER_BIT - 1) begin
                    clk_counter <= clk_counter + 1;
                end else begin
                    clk_counter <= 0;
                    rx_parity_bit <= rx_s;
                    state <= S_STOP;
                end
            end

            // --- STOP BIT ---
            S_STOP: begin
                if (clk_counter < CYCLES_PER_BIT - 1) begin
                    clk_counter <= clk_counter + 1;
                end else begin
                    clk_counter <= 0;
                    state <= S_COMPLETE;
                end
            end

            // --- COMPLETE ---
            S_COMPLETE: begin
					 if(flag == 0) begin 
						 if(clk_counter < 10) begin
							  clk_counter <= clk_counter + 1;
						 end else begin
							  clk_counter <= 0;
							  if (rx_parity_bit != (^rx_data))
									rx_msg <= 8'h3F; // parity error
							  else
									rx_msg <= rx_data;
							  rx_parity <= rx_parity_bit;
							  if (rx_msg == 8'b0) begin
									if(rx_complete_2 == 0) begin
										rx_complete <= 1'b1;
										rx_complete_2 <= 1'b1;
									end else begin
										rx_complete <= 1'b0;
									end
							  end else 
									rx_complete <= 1'b1;
							  state <= S_IDLE;  // return to idle
						 flag <= 1;
						 end
					 end else begin
						 if(clk_counter < 9) begin
							  clk_counter <= clk_counter + 1;
						 end else begin
							  clk_counter <= 0;
							  if (rx_parity_bit != (^rx_data))
									rx_msg <= 8'h3F; // parity error
							  else
									rx_msg <= rx_data;
							  rx_parity <= rx_parity_bit;
							  if (rx_msg == 8'b0) begin
									if(rx_complete_2 == 0) begin
										rx_complete <= 1'b1;
										rx_complete_2 <= 1'b1;
									end else begin
										rx_complete <= 1'b0;
									end
							  end else 
									rx_complete <= 1'b1;
							  state <= S_IDLE;  // return to idle
						 end
					 end
            end
        endcase
    end

/* Add your logic here */

//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE//////////////////

endmodule