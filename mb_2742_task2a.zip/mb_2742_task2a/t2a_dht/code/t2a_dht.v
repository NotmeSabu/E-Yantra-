
module t2a_dht(
    input clk_50M,
    input reset,
    inout sensor,
    output reg [7:0] T_integral,
    output reg [7:0] RH_integral,
    output reg [7:0] T_decimal,
    output reg [7:0] RH_decimal,
    output reg [7:0] Checksum,
    output reg data_valid
);

    initial begin
        T_integral = 0;
        RH_integral = 0;
        T_decimal = 0;
        RH_decimal = 0;
        Checksum = 0;
        data_valid = 0;
    end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

	 parameter CLK_FREQ       = 50000000;
    parameter US_COUNT       = CLK_FREQ / 1000000;
    parameter INITIAL_DELAY  = 18000; // 18ms low
    parameter INITIAL_HIGH   = 40;    // 40us high
    parameter RESPONSE       = 80;    // 80us sensor response

    // ===================== STATES =====================
    parameter ST_INITIAL_LOW   = 3'b000, 
              ST_INITIAL_HIGH  = 3'b001, 
              ST_RESPONSE_LOW  = 3'b010, 
              ST_RESPONSE_HIGH = 3'b011,
              ST_DATA          = 3'b100,
              ST_UPDATE_WAIT   = 3'b101,
              ST_DONE          = 3'b110;

    // ===================== INTERNAL SIGNALS =====================
    reg [2:0] state = ST_INITIAL_LOW;
    reg [31:0] counter = 0;
    reg [31:0] pulse_counter = 0; 
    reg [40:0] dataframe = 0;
    reg [5:0] bit_count = 0;
    reg [1:0] update_delay = 0;  // 🔹 2-cycle update delay counter

    // Tri-state logic for sensor line
    reg sensor_out;
    reg sensor_oe;
    assign sensor = sensor_oe ? sensor_out : 1'bz;
    wire sensor_in = sensor;

    // ===================== MAIN FSM =====================
    always @(posedge clk_50M or negedge reset) begin
        if (!reset) begin
            state <= ST_INITIAL_LOW;
            counter <= 0;
            pulse_counter <= 0;
            dataframe <= 0;
            bit_count <= 0;
            sensor_oe <= 1;
            sensor_out <= 1;
            data_valid <= 0;
            update_delay <= 0;
        end else begin
            case (state)

                // ---------------------------------------------------
                // 1. MCU pulls line LOW for 18ms to start transmission
                // ---------------------------------------------------
                ST_INITIAL_LOW: begin
                    sensor_oe <= 1;
                    sensor_out <= 0;
                    
                    if (counter >= US_COUNT * INITIAL_DELAY) begin
                        counter <= 0;
                        state <= ST_INITIAL_HIGH;
                    end else counter <= counter + 1;
                end

                // ---------------------------------------------------
                // 2. MCU releases line HIGH for 40us
                // ---------------------------------------------------
                ST_INITIAL_HIGH: begin
                    sensor_oe <= 1;
                    sensor_out <= 1;
                    if (counter >= US_COUNT * INITIAL_HIGH) begin
                        sensor_oe <= 0; // release line
                        counter <= 0;
                        state <= ST_RESPONSE_LOW;
                    end else counter <= counter + 1;
                end

                // ---------------------------------------------------
                // 3. Sensor responds LOW (~80us)
                // ---------------------------------------------------
                ST_RESPONSE_LOW: begin
                    if (!sensor_in) counter <= counter + 1;
                    else begin
                        counter <= 0;
                        state <= ST_RESPONSE_HIGH;
                    end
                end

                // ---------------------------------------------------
                // 4. Sensor responds HIGH (~80us)
                // ---------------------------------------------------
                ST_RESPONSE_HIGH: begin
                    if (sensor_in) counter <= counter + 1;
                    else begin
                        counter <= 0;
                        bit_count <= 0;
                        pulse_counter <= 0;
                        dataframe <= 0;
                        state <= ST_DATA;
                    end
                end

                // ---------------------------------------------------
                // 5. Read 40 bits of data
                // ---------------------------------------------------
                ST_DATA: begin
                    if (bit_count < 41) begin
                        if (sensor_in == 1) begin
                            pulse_counter <= pulse_counter + 1;
                        end else begin
                            if (pulse_counter != 0) begin
                                if (pulse_counter > US_COUNT * 50)
                                    dataframe <= {dataframe[39:0], 1'b1};
                                else
                                    dataframe <= {dataframe[39:0], 1'b0};
                                
                                bit_count <= bit_count + 1;
                                pulse_counter <= 0;
                            end
                        end
                    end 
                    else begin
                        // ✅ Move to update delay phase
                        update_delay <= 0;
                        state <= ST_UPDATE_WAIT;
                    end
                end

                // ---------------------------------------------------
                // 6. Wait 2 clock cycles before updating outputs
                // ---------------------------------------------------
                ST_UPDATE_WAIT: begin
                    update_delay <= update_delay + 1;
                    if (update_delay == 1) begin
                        RH_integral <= dataframe[39:32];
                        RH_decimal  <= dataframe[31:24];
                        T_integral  <= dataframe[23:16];
                        T_decimal   <= dataframe[15:8];
                        Checksum    <= dataframe[7:0];

                        if (Checksum == RH_integral + RH_decimal + T_integral + T_decimal)
                            data_valid <= 1'b1;
                        else
                            data_valid <= 1'b0;

                        state <= ST_DONE;
                    end
                end

                // ---------------------------------------------------
                // 7. Wait until Hi-Z before restarting
                // ---------------------------------------------------
                ST_DONE: begin
                    if (sensor_in === 1'bz) begin
                        counter <= 0;
                        bit_count <= 0;
                        dataframe <= 0;
                        pulse_counter <= 0;
								data_valid <= 1'b0;
                        state <= ST_INITIAL_LOW;
                    end
                end

            endcase
        end
    end



//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////
  
endmodule
