
module pwm_generator(
    input clk_3125KHz,
    input [3:0] duty_cycle,
    output reg clk_195KHz, pwm_signal
);

initial begin
    clk_195KHz = 0; pwm_signal = 1;
end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

	 reg [3:0] counter = 4'd0;

   
    always @(posedge clk_3125KHz) begin
        // Counter logic: increments on each clock and wraps from 15 back to 0.
        counter <= counter + 1;


        // 1. Generate the fixed 50% duty cycle clock (195.3125 KHz).
        //    High for the first 8 counts (0-7), low for the next 8 (8-15).
        if (counter < 8) begin
            clk_195KHz <= 1'b1;
        end else begin
            clk_195KHz <= 1'b0;
        end

        // 2. Generate the variable PWM signal based on the duty_cycle input.
        //    The signal is high as long as the counter value is less than the duty_cycle value.
        if (counter < duty_cycle) begin
            pwm_signal <= 1'b1;
        end else begin
            pwm_signal <= 1'b0;
        end
    end


//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule
