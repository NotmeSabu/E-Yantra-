/*
Module HC_SR04 Ultrasonic Sensor

This module will detect objects present in front of the range, and give the distance in mm.

Input:  clk_50M - 50 MHz clock
        reset   - reset input signal (Use negative reset)
        echo_rx - receive echo from the sensor

Output: trig    - trigger sensor for the sensor
        op     -  output signal to indicate object is present.
        distance_out - distance in mm, if object is present.
*/

// module Declaration
module t1b_ultrasonic(
    input clk_50M, reset, echo_rx,
    output reg trig,
    output op,
    output wire [15:0] distance_out
);

initial begin
    trig = 0;
end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

parameter CLK_FREQ = 50000000;             // 50 MHz clock frequency
parameter US_COUNT = CLK_FREQ / 1000000;   // Clock cycles for 1 microsecond
parameter TRIG_PULSE_US = 10;              // 10 µs trigger pulse duration
parameter TRIG_DELAY_US = 12000;           // 12 ms delay between triggers
parameter SENSOR_SETTLE_US = 1;            // 1 µs initial delay for sensor settling
// FSM states
reg [2:0] state;
parameter RESET           = 3'd0;
parameter SETTLE          = 3'd1;
parameter TRIGGER         = 3'd2;
parameter WAIT_ECHO_HIGH  = 3'd3;
parameter MEASURE_ECHO    = 3'd4;
parameter DELAY           = 3'd5;
// Internal counters
reg [16:0] counter;        // General purpose counter for short delays
reg [19:0] cycle_counter;  // Counter for the 12ms measurement cycle
// Output registers
reg [15:0] distance_reg=16'd0;
reg op_reg;
// Drive outputs from registers
assign distance_out = distance_reg;
assign op = op_reg;
always @(posedge clk_50M) begin
    if (!reset) begin
        trig <= 0;
        counter <= 0;
        cycle_counter <= 0;
        distance_reg <= 0;
        op_reg <= 0;
        state <= RESET;
    end else begin
        case (state)
            RESET: begin
                trig <= 0;
                counter <= 0;
                cycle_counter <= 0;
                distance_reg <= 0;
                op_reg <= 0;
                state <= SETTLE;
            end

            // 1 µs sensor settle
            SETTLE: begin
                if (counter < SENSOR_SETTLE_US * US_COUNT - 2)
                    counter <= counter + 1;
                else begin
                    counter <= 0;
                    state <= TRIGGER;
                end
            end

            // 10 µs trigger pulse
            TRIGGER: begin
                trig <= 1;
                cycle_counter <= 0;
                if (counter < TRIG_PULSE_US * US_COUNT)
                    counter <= counter + 1;
                else begin
                    trig <= 0;
                    counter <= 0;
                    if (!echo_rx)
                        distance_reg <= 0;
                    state <= WAIT_ECHO_HIGH;
                end
            end

            // Wait for echo to start
            WAIT_ECHO_HIGH: begin
                cycle_counter <= cycle_counter + 1;
                if (echo_rx) begin
                    counter <= 0; // reset counter to start measuring echo width
                    state <= MEASURE_ECHO;
                end
                if (cycle_counter >= TRIG_DELAY_US * US_COUNT)
                    state <= SETTLE;
            end

            // Measure echo pulse width using counter
            MEASURE_ECHO: begin
                cycle_counter <= cycle_counter + 1;
                if (echo_rx)
                    counter <= counter + 1; // measure echo width
                else begin
                    // Calculate distance
                    distance_reg <= (counter * 34) / 10000;  
                    op_reg <= ((counter * 34) / 10000) < 70;
						  counter <= 0;
                    state <= DELAY;
                end
                if (cycle_counter >= TRIG_DELAY_US * US_COUNT)
                    state <= SETTLE;
            end

            // Delay until 12ms cycle ends
            DELAY: begin
                cycle_counter <= cycle_counter + 1;
                if (cycle_counter >= TRIG_DELAY_US * US_COUNT + 3)
                    state <= SETTLE;
            end

            default: state <= RESET;
        endcase
    end
end

//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule
