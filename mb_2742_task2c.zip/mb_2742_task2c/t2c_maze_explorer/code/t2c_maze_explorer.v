// Task 2C - MazeSolver Bot

module t2c_maze_explorer (
    input clk,
    input rst_n,
    input left, mid, right, // 0 - no wall, 1 - wall
    output reg [2:0] move
);

/*

| cmd | move  | meaning   |
|-----|-------|-----------|
| 000 | 0     | STOP      |
| 001 | 1     | FORWARD   |
| 010 | 2     | LEFT      |
| 011 | 3     | RIGHT     | 
| 100 | 4     | U_TURN    |

START POS   : 4,0
EXIT POS    : 4,8
DEADENDS    : 9

*/
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

    // --- Define parameters for motor commands for readability ---
    localparam STOP    = 3'b000; 
    localparam FORWARD = 3'b001; 
    localparam LEFT    = 3'b010; 
    localparam RIGHT   = 3'b011; 
    localparam U_TURN  = 3'b100; 

    // --- Main FSM (Left-Hand Wall Follower) ---
    // This is a single-state FSM that continuously updates the
    // 'move' command based on sensor inputs at every clock edge.
    
    always @(posedge clk or negedge rst_n) begin
    
        // Active-low reset
        if (!rst_n) begin
            move <= STOP;
        end
        
        // Main algorithm logic
        else begin
            
            // --- Left-Hand Rule Decision Tree ---
            // Inputs: left, mid, right
            // 0 = no wall, 1 = wall
            
            // 1. Is there a wall on the left?
            if (left == 1'b0) begin
                // NO. Turn LEFT.
                move <= LEFT;
            end
            
            // 2. Is there a wall on the left? YES.
            //    Is there a wall in front?
            else if (mid == 1'b0) begin
                // NO. Move FORWARD.
                move <= FORWARD;
            end
            
            // 3. Is there a wall on the left? YES.
            //    Is there a wall in front? YES.
            //    Is there a wall on the right?
            else if (right == 1'b0) begin
                // NO. Turn RIGHT.
                move <= RIGHT;
            end
            
            // 4. Is there a wall on the left? YES.
            //    Is there a wall in front? YES.
            //    Is there a wall on the right? YES.
            //    This is a dead end.
            else begin
                // Action: U_TURN.
                move <= U_TURN;
            end
        end
    end

//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule
